"""Single source of truth for user-facing failure identity.

Every surface (Desktop, CLI, Quick Access and the privileged helpers) resolves
failures through this module so one underlying fault always reports the same
stable ``BC250-<AREA>-<NNN>`` identifier, cause and next step.

Three vocabularies existed before this module and disagreed with each other:
the regex rules in the desktop layer, a ``BC250-TERM-<status>`` string built
inside the generated shell script, and a separate TypeScript reimplementation
in the Quick Access panel. A fourth problem was mechanical: helpers exit with
codes 10-57 that no table explained, so the interface printed the bare number.

Text lives here as English source strings because ``tr()`` keys are the English
strings themselves. Keep the wording bounded and reusable; every new sentence
costs 30 translations.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ErrorCode:
    """One diagnosable failure with a stable identifier and a next step."""

    code: str
    summary: str
    cause: str
    action: str
    # Process exit statuses that mean exactly this failure. Used to translate a
    # helper's numeric status instead of printing it raw.
    exit_statuses: tuple[int, ...] = ()
    # ``PREFIX:`` markers helpers already print on stderr.
    markers: tuple[str, ...] = ()
    retryable: bool = False
    # Text that must also be present for the markers to count. pacman ends every
    # failed download the same way, whatever made it fail.
    requires: str = ""


# Reserved: the terminal wrapper previously emitted BC250-TERM-<status> for any
# status, including ones no table explained. Statuses now resolve through
# ``for_exit_status`` and fall back to BC250-GENERAL-001 rather than minting an
# identifier that nothing can look up.

# Every entry reuses wording that already exists in the desktop diagnostic
# rules, so all 30 locales already translate it. Adding a status or marker
# here costs no new translation work; inventing new sentences would.
_CODES: tuple[ErrorCode, ...] = (
    # First in the catalog on purpose: a later text rule wins, and these four
    # name what stopped, never why. The lists apt could not refresh are often
    # somebody else's broken repository (R-e33c7380, R-d798ec44).
    ErrorCode(
        "BC250-PKG-008",
        "A package repository of this system could not be refreshed by apt.",
        "The Err: lines above name it: usually a repository added earlier whose key is missing or whose certificate is not valid. apt goes on with its old list, so this may not be what stopped the action.",
        "Fix what the lines above the error name, then run this action again.",
        markers=("Some index files failed to download",),
    ),
    # R-fc1cfbe2, R-f4c9a114: pacman's last words, the cause is above them.
    ErrorCode(
        "BC250-PKG-009",
        "pacman stopped without changing anything.",
        "pacman aborted the installation. A full or read-only disk is the most common reason; the lines above the error name it when pacman knows it.",
        "Fix what the lines above the error name, then run this action again.",
        markers=("failed to commit transaction .transaction aborted",),
    ),
    # R-767bbe68, R-536c885c, R-d2cec179, R-a45942d4.
    ErrorCode(
        "BC250-UPSCALE-003",
        "HelixSR's setup could not build its network files.",
        "HelixSR builds them with a Windows shader compiler that runs in Wine. The compiler or Wine stopped, or a file it needs was missing. Games that already use HelixSR were not changed.",
        "In Steam, verify the files of the Proton version in use, then run this action again.",
        # No brackets: the terminal wrapper reads markers as regular expressions.
        markers=("helixsr-setup. error:", "The network was not built. HelixSR is installed"),
    ),
    # The computer of R-f31ee6a1, R-90b7cec7 and R-3650e716 was not a BC-250.
    ErrorCode(
        "BC250-GPU-009",
        "Cyan did not find the BC-250 GPU.",
        "Cyan looks for the GPU at one fixed PCI address. Either this computer is not a BC-250, or another PCIe device moved the GPU to a different address.",
        "This action is only for a BC-250. If this computer is one, send a report with this code.",
        markers=("Cyan Skillfish GPU not found at expected PCI bus",),
    ),
    ErrorCode(
        "BC250-CMD-001",
        "A required program or generated command is missing.",
        "Dependencies were not prepared, a toolkit was removed, or the active distribution provides the program under a different package or path.",
        "Return to the Dashboard and prepare the affected module.",
        exit_statuses=(31, 47, 48, 127),
        markers=(),
    ),
    ErrorCode(
        "BC250-TERMINAL-001",
        "The required terminal workflow could not be started.",
        "No supported graphical terminal was found, its launcher rejected the command, or a required executable is absent.",
        "Install a supported terminal or run the private script path shown in the technical detail from your existing terminal.",
        exit_statuses=(126,),
        markers=(),
    ),
    ErrorCode(
        "BC250-TIMEOUT-001",
        "The operation did not finish within its safety limit.",
        "A service, hardware read-back, package download, or external toolkit stopped responding or needed longer than expected.",
        "Check whether the terminal or service is still active, then review its log. Retry only after the previous process has ended.",
        exit_statuses=(124, 125),
        markers=('QUICK_ACCESS_TIMEOUT', 'GDDR6 patch did not finish in time', 'Timeout was reached'),
    ),
    ErrorCode(
        "BC250-DATA-001",
        "The workflow rejected an existing or inconsistent configuration.",
        "A repository, toolkit file, package source, or saved value already exists in a form the workflow will not overwrite automatically.",
        "Read the ERROR line immediately above the exit code, correct the named configuration, and run the workflow again.",
        exit_statuses=(65,),
        markers=(),
    ),
    ErrorCode(
        "BC250-PERM-001",
        "Linux refused access to a required file or device.",
        "A helper, device node, configuration file, or immutable system path has ownership or permission settings that do not allow this operation.",
        "Reinstall this version so its helpers are in place. On Bazzite or SteamOS, finish any pending deployment and restart before retrying.",
        exit_statuses=(11, 13, 14, 15, 16, 17, 71, 77),
        markers=("QUICK_ACCESS_PRIVILEGE",),
    ),
    ErrorCode(
        "BC250-PERM-002",
        "Linux refused access to a required file or device.",
        "A helper, device node, configuration file, or immutable system path has ownership or permission settings that do not allow this operation.",
        "Return to the Dashboard and prepare the affected module.",
        markers=("Untrusted helper dependency:", "is not protected by root:",
                 "CU executor is missing or untrusted", "HELPER_UNTRUSTED:"),
    ),
    ErrorCode(
        "BC250-SERVICE-003",
        "The service manager could not complete the requested change.",
        "The service configuration is invalid, its executable is missing, or the selected init system does not match the installed service files.",
        "Open the service status and read the first reported error. Repair the module from the Dashboard before enabling it again.",
        exit_statuses=(69,),
        markers=('QUICK_ACCESS_GPU_SERVICE', 'QUICK_ACCESS_GPU_CONFLICT'),
    ),
    ErrorCode(
        "BC250-VRAM-001",
        "The VRAM size could not be changed.",
        "The size is not one of the offered presets, the firmware memory layout was not recognised, or the CMOS ports could not be reached.",
        "Choose one of the offered sizes. If it repeats, apply it from BC250 Control Center Desktop, which checks the firmware layout first.",
        markers=('QUICK_ACCESS_VRAM',),
    ),
    ErrorCode(
        "BC250-TTM-001",
        "The GPU memory limit could not be changed.",
        "This system cannot keep a kernel boot argument the way Control Center manages it, another tool already set the limit, or the boot loader or rpm-ostree refused the change.",
        "Read the reason in the Memory section. On SteamOS, systemd-boot or rEFInd add the ttm.pages_limit argument yourself; elsewhere retry once the boot loader or rpm-ostree is idle.",
        markers=('QUICK_ACCESS_TTM',),
    ),
    # bash's "fork: retry: Resource temporarily unavailable": a process limit
    # or no memory left, not a problem of the step that could not start.
    ErrorCode(
        "BC250-RESOURCE-001",
        "The system could not start another process.",
        "The system reached its limit of running processes, or it is out of memory, so a step of the workflow could not start.",
        "Close programs you do not need, or restart the computer, then run the action again.",
        markers=("fork: retry: Resource temporarily unavailable", "fork: Resource temporarily unavailable", "Cannot allocate memory"),
    ),
    # The terminal's side of the window rule: a workflow that meets another
    # package manager's lock said "the operation could not be completed".
    ErrorCode(
        "BC250-PKG-001",
        "The package manager is busy.",
        "A system update, software center, or another terminal is already changing packages.",
        "Let that update finish, close the other package tool, and retry. Do not delete package-manager lock files by hand.",
        markers=(
            "unable to lock database", "could not lock database", "Could not get lock", "database is locked",
            "Waiting for cache lock", "System management is locked by the application",
            # The pacman lock release refusing while a package manager runs.
            "so pacman is busy",
        ),
    ),
    # dnf "nothing provides", apt "unmet dependencies", pacman "target not
    # found", zypper/apk "unable to satisfy": the package is not there.
    ErrorCode(
        "BC250-PKG-004",
        "A required package is not available from the enabled repositories.",
        "The package, or one of its dependencies, is not published for this distribution or release, or the repository that provides it is not enabled.",
        "Read the package named in the output. Enable the repository that provides it, or report the workflow with this code so the package list can be fixed.",
        markers=('nothing provides', 'has unmet dependencies', 'Unmet dependencies', 'unable to satisfy dependency', 'could not satisfy dependencies', 'error: target not found',
                 # rpm-ostree, for a layered package the repositories no longer carry (R-506fdded).
                 'Packages not found', 'Could not depsolve transaction',),
    ),
    # Wine's loader, when kernel32.dll is missing from the prefix or the build.
    ErrorCode(
        "BC250-WINE-001",
        "Wine could not start.",
        "Wine could not load its own Windows files, so the Proton build it uses or its Wine prefix is incomplete.",
        "In Steam, verify the files of the Proton version in use, then run this action again.",
        markers=(
            "could not load kernel32.dll",
        ),
    ),
    # bash's own words for an executable whose loader or a library is absent
    # (a Toolbx or an incomplete Proton); the file passes ``test -x``, so the
    # HelixSR shader build gets this far before stopping (R-a45942d4).
    ErrorCode(
        "BC250-WINE-002",
        "Wine or Proton cannot run in this environment.",
        "The Wine program that HelixSR uses to compile its shaders exists, but Linux cannot execute it here: a loader or library it depends on is missing, which happens inside a Toolbx or Distrobox container or with an incomplete Proton.",
        "In Steam, verify the files of the Proton version in use, or install Wine for this system. Inside a container, install the libraries Wine needs there, then run this action again.",
        markers=(
            "cannot execute: required file not found",
            "cannot be executed here",
        ),
        requires="wine",
    ),
    # Rootless Podman with no subordinate IDs: the image downloads, then its
    # first layer cannot be unpacked (R-32e499fb). container_network stops the
    # build earlier with the second marker and the commands that fix it.
    ErrorCode(
        "BC250-CONTAINER-001",
        "Rootless Podman has no subordinate user IDs for this user.",
        "Podman builds this component in a container as your user, which needs a range of subordinate user and group IDs in /etc/subuid and /etc/subgid. Your user has none, or Podman has not picked up a range that was added, so the container image could not be unpacked.",
        "Run the commands printed just above the error: they add the range for your user and let Podman pick it up. Then run this action again.",
        markers=(
            "insufficient UIDs or GIDs available in user namespace",
            "has no subordinate user and group IDs",
        ),
    ),
    # HelixSR's bridge refuses a game with an anti-cheat unless told
    # ``--anticheat-ok yes``, which Control Center never passes (R-c6ab33f2).
    ErrorCode(
        "BC250-UPSCALE-002",
        "HelixSR refused this game because of its anti-cheat.",
        # No "nothing was changed" promise: install_helixsr_bridge migrates a
        # HelixSR 2 game before the bridge can refuse (B8 reorders that).
        "HelixSR's bridge reports that the game uses an anti-cheat such as EasyAntiCheat. Replacing its upscaler files can get the account banned in online play, so HelixSR's bridge declined to install it.",
        "Use HelixSR with games that have no anti-cheat. Control Center never overrides this check on its own.",
        # No bare "EasyAntiCheat": a game-folder listing names that directory.
        markers=(
            "has anti-cheat",
            "anticheat-ok",
        ),
    ),
    ErrorCode(
        "BC250-STORAGE-001",
        "There is not enough writable storage.",
        "The target filesystem, temporary directory, boot partition, or user quota is full.",
        "Free space on the filesystem named in the technical detail, then retry. Kernel installs also require free space in /boot.",
        exit_statuses=(73, 74),
        # steamos-root.sh: /var or the root filesystem is too full to install.
        markers=('MB free and this needs', 'SteamOS keeps /var small',
                 # bazzite_memory_tuning.py and the mutable adapter's swapfile check.
                 'not enough free space on', 'Insufficient disk space',
                 'no space left on device', 'No space left on device'),
    ),
    ErrorCode(
        "BC250-BUSY-001",
        "Another operation is still using this component.",
        "A previous BC250 action, package manager, service restart, or external toolkit still holds the required lock.",
        "Wait for the current terminal or progress indicator to finish, refresh the page, and retry once. Close other BC250 toolkits if the lock remains.",
        exit_statuses=(75,),
        # The SMU mailbox gave no answer in time (0x00) or said it was busy
        # (0xFC). The CPU/SMU helper exits 70 for it, which alone reads as a
        # helper version mismatch and sent users to reinstall.
        markers=('Transaction in progress', 'another BC250 system preparation is already running',
                 'Another BC250 system setup change is running', "index.lock': File exists", 'Another git process seems to be running', 'smu returned status 0x00', 'smu returned status 0xFC', 'smu timed out after',
                 # The CPU helper exits 44 (a RANGE status) for it.
                 'SMU_IN_USE'),
    ),
    ErrorCode(
        "BC250-CONFIG-001",
        "A configuration file is invalid or incomplete.",
        "A manual edit, older toolkit, interrupted write, or unsupported option left syntax or values the current component cannot read.",
        "Open the named file from the application, correct the first reported line or restore the module defaults, then apply the settings again.",
        exit_statuses=(78,),
        markers=('QUICK_ACCESS_GPU_CONFIG', 'Cyan configuration is not usable', 'QUICK_ACCESS_GPU_SAFE_POINT: invalid TOML ceiling'),
    ),
    ErrorCode(
        "BC250-PROTOCOL-001",
        "The interface and protected helper are different versions.",
        "An older Desktop or Decky component is still running after an update, or only part of the application was replaced.",
        "Reinstall the current build and restart the application. Restart Decky Loader too when the Quick Access panel is affected.",
        exit_statuses=(2, 3, 28, 29, 32, 33, 36, 49, 70, 90),
        markers=(
            'Missing action.', 'Unknown action.', 'expects:',
            'does not accept arguments', 'accepts only', 'HELPER_USAGE',
            'QUICK_ACCESS_CU_SERVICE:', 'QUICK_ACCESS_CPU_SERVICE:',
            # A fresh Decky build talking to a stale installed helper (or the
            # reverse) after only one side of an update was applied. This is
            # a routine, expected state right after replacing the helper --
            # not a hardware fault -- so it must resolve to this calm,
            # actionable code instead of the generic unknown-failure one.
            'are different versions.', 'disagrees with this system about',
            'was built for contract revision', 'protocol is incompatible',
            'shared contract is not installed',
            'shared contract is not a protected root-owned file',
            'shared contract could not be read',
        ),
    ),
    ErrorCode(
        "BC250-DBUS-001",
        "The GPU governor did not expose its D-Bus controls.",
        "Cyan is stopped, still starting, using an incompatible configuration, or another governor owns the GPU control path.",
        "Check the governor service status, resolve any Cyan/Oberon conflict, start the selected service, and wait a few seconds before refreshing.",
        exit_statuses=(22,),
        # Cyan's own start steps exit 62, which Compute Units owns; without
        # these a governor that would not start was reported as a CU fault.
        markers=('QUICK_ACCESS_GPU_DBUS',
                 'D-Bus name is unavailable', 'Cyan D-Bus policy',
                 'busctl is required for Cyan'),
    ),
    # After BC250-DBUS-001 on purpose: text rules are checked in order and the
    # last match wins, and a leftover sensor mount is the more precise cause
    # of a Cyan that never publishes its bus name. Wording shared with the
    # desktop rule of the same code.
    ErrorCode(
        "BC250-GPU-005",
        "The governor could not put its patched sensor files in place.",
        "Cyan replaces two GPU sensor files with patched copies while it runs. One replacement from an earlier run is still in place, so the new one cannot be made and the service stops.",
        "Stop the governor, undo the leftover replacement on the path named in the technical detail, then start it again. If it keeps happening, turn off Fix metrics and Fix frequencies.",
        markers=('patched_gpu_metrics', 'patched_freq_metrics', 'move_mount', 'mount --bind'),
    ),
    # The voltage curve is written through the running Cyan; with Cyan stopped
    # the edit is refused before anything is changed (R-cbc5ba02, R-5577dbea).
    ErrorCode(
        "BC250-GPU-008",
        "Cyan is not running, so the voltage curve was not changed.",
        "The voltage curve is applied through the running governor: Cyan has to be active so the new values can be written, read back and verified.",
        "Press Start governor on the governor card, wait a few seconds until it shows Connected, then apply the voltage curve again.",
        markers=('must be active before changing its voltage curve',),
    ),
    ErrorCode(
        "BC250-RANGE-001",
        "The requested value is outside the supported range.",
        "The value does not match the active hardware table, available RAM, safe points, or the limits enforced by the selected backend.",
        "Choose a value currently offered by the application. Refresh first if another toolkit or a restart may have changed the live limits.",
        exit_statuses=(20, 21, 23, 24, 34, 35, 37, 38, 39, 41, 42, 43, 44, 45, 56, 92),
        markers=('QUICK_ACCESS_GPU_PROFILE', 'QUICK_ACCESS_GPU_SAFE_POINT',
                 'QUICK_ACCESS_GPU_HIGH_POINTS', 'QUICK_ACCESS_GPU_ALLOWED', 'QUICK_ACCESS_GPU_VOLTAGE',
                 # Longer than QUICK_ACCESS_CU_MODE, so a numeric check is not a CU fault.
                 'target must be an even value from 24 through 40', 'QUICK_ACCESS_GPU_VERIFY', 'QUICK_ACCESS_CPU_SCALE', 'Frequency must be between', 'VID must be between', 'Temperature must be between', 'QAM CPU frequency must be', 'QAM CPU VID must be', 'QAM CPU detection uses a fixed', 'HELPER_RANGE'),
    ),
    ErrorCode(
        "BC250-CU-001",
        "The Compute Units operation could not be verified.",
        "UMR, the GPU database, the live manager, the saved WGP map, or the AMDGPU topology may not match the running kernel and Mesa stack.",
        "Run Unlock/Sync again, check the displayed live map, prepare UMR if missing, and apply only after the requested and driver maps agree.",
        exit_statuses=(30, 62, 63),
        markers=(
            'QUICK_ACCESS_CU_TABLE', 'QUICK_ACCESS_CU_KERNEL', 'QUICK_ACCESS_CU_MODE', 'QUICK_ACCESS_CU_BACKEND',
            'QUICK_ACCESS_CU_SERVICE_REMOVE', 'QUICK_ACCESS_CU_STATE',
            'QUICK_ACCESS_CU_VERIFY', 'QUICK_ACCESS_CU_SERVICE_PROFILE',
            'QUICK_ACCESS_CU_SERVICE_VERIFY',
        ),
    ),
    # Prepare dependencies rebuilt UMR and it still does not start. After
    # BC250-CU-001 so the more precise rule wins.
    ErrorCode(
        "BC250-UMR-001",
        'UMR is not working.',
        'UMR is the program Control Center uses to read and change the Compute Units. It does not start or cannot read the GPU, usually because a system update replaced a library it needs.',
        'Reinstall UMR by following these steps:',
        markers=(
            'UMR still does not start',
            'umr is installed but does not start',
        ),
    ),
    ErrorCode(
        "BC250-FAN-001",
        "The fan control path is unavailable or rejected the write.",
        "The NCT driver may be read-only, the hwmon number may have changed, the selected PWM channel may not exist, or another fan service is controlling it.",
        "Refresh fan detection, confirm the physical channel, prepare NCT6687 PWM support, and stop other fan-control tools before retrying.",
        exit_statuses=(25, 26, 27, 40, 46),
        markers=('QUICK_ACCESS_FAN', 'fan/PWM hwmon', 'usable nct6687 module',
                 'nct6687d PWM driver workflow', 'nct6687 could not be loaded',
                 'persisted nct6687 source is missing'),
    ),
    ErrorCode(
        "BC250-FAN-002",
        "The fan is handed to another program.",
        "On the Fans page the fan was handed to another program, such as CoolerControl, so BC250 Control Center does not write to it.",
        "Use that program to change the fan, or press Take control back on the Fans page first.",
        exit_statuses=(58,),
        markers=('FAN_EXTERNAL', 'QUICK_ACCESS_FAN_EXTERNAL'),
    ),
    # Our own driver scripts: a kernel, header or module-build mismatch. After
    # BC250-FAN-001 on purpose: a later text rule wins, so a PWM build that
    # stopped on headers is not reported as a fan fault.
    ErrorCode(
        "BC250-KERNEL-001",
        'The running kernel and its driver or headers do not match.',
        'The machine may still be running the old kernel, headers may be missing, Secure Boot may reject the module, or a partial update mixed versions.',
        'Restart into the intended BC250 kernel, verify its matching headers, then repair the affected driver. Review Secure Boot only if the module log names it.',
        markers=(
            'kernel and headers do not match',
            'headers for exactly',
            'headers for another kernel',
            'exact Neptune headers',
            'replaced the running kernel',
            'Module/kernel mismatch',
            'Could not read vermagic',
            'installed for the active kernel',
            'match the active immutable kernel',
            'nct6687 build failed',
            'DKMS installation did not produce a module',
            'PWM build prerequisites',
            'nct6687.ko was not produced',
            'nct6687 is not available for',
            'kernel-devel mismatch',
            'matching kernel-devel is unavailable',
            'rebuilt nct6687 has vermagic',
        ),
    ),
    # After FAN-001 and KERNEL-001, whose words the same output carries
    # (R-e33c7380, R-adbf79fa: the computer was not a BC-250).
    ErrorCode(
        "BC250-FAN-003",
        "No NCT668x fan chip answered.",
        "The driver read an ID that does not belong to the fan chip of the BC-250, so it refused to load.",
        "This action is only for a BC-250. If this computer is one, send a report with this code.",
        markers=("chip ID 0xffff is outside the Nuvoton",),
    ),
    ErrorCode(
        "BC250-CPU-001",
        "The CPU tuning result could not be applied or verified.",
        "The stress dependency, SMU helper, same-boot detector evidence, temperature limit, or selected frequency and VID do not satisfy the validated workflow.",
        "Run automatic detection for this exact frequency first. Keep the terminal open, monitor temperature, and save the service only after the live result is verified.",
        exit_statuses=(50, 51, 52, 53, 54, 55, 57, 60, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 91, 93, 94),
        markers=('QUICK_ACCESS_CPU', 'QUICK_ACCESS_CPU_VERIFY', 'QUICK_ACCESS_CPU_SERVICE', 'QUICK_ACCESS_CPU_SCALE_VERIFY', 'stress is required by bc250-detect', 'Run automatic detection at this exact frequency', 'Manual scale must reuse the detected thermal limit', 'bc250-detect returned values outside the requested', 'bc250-detect did not produce a valid configuration',
                 # Any other SMU mailbox refusal; the shorter marker loses to
                 # the no-answer and busy ones under BC250-BUSY-001.
                 'smu returned status 0x'),
    ),
    ErrorCode(
        "BC250-AUTH-002",
        "Administrator authorization was not completed.",
        "The password dialog was cancelled, closed, timed out, or rejected the supplied password.",
        "Run the action again and finish the administrator password dialog.",
        exit_statuses=(),
        markers=('incorrect password attempt', 'sudo: timed out reading password', 'sudo: a password is required', 'Error executing command as another user: Not authorized', 'QUICK_ACCESS_AUTH',),
    ),
    # Quick Access refuses to run at all: not root, no systemd host, or no
    # BC-250 present. All three exit 10, so the marker decides which applies.
    ErrorCode(
        "BC250-HW-001",
        "Compatible BC-250 hardware was not detected.",
        "The AMDGPU device is unavailable, the application is running in a container or remote session, or the active kernel did not bind the BC-250 GPU.",
        "Verify that lspci shows 1002:13fe and that AMDGPU is loaded. Restart into the BC250 kernel if the device is present without a driver.",
        exit_statuses=(10, 12, 18, 19),
        markers=('probe with driver amdgpu failed', 'The GPU driver (amdgpu) did not start', 'invalid ip discovery binary signature', "HARDWARE_CONTEXT", "QUICK_ACCESS_CONTEXT",
                 # The scripts' own PCI checks (bazzite_async_compute, steamos_amdgpu,
                 # bc250_fsr4) and Cyan's service on a PC that is not a BC-250. Both
                 # spellings: ``for_marker`` is case-sensitive.
                 '13fe was not found', '13fe was not detected', '13FE was not detected',
                 'expected PCI bus location'),
    ),
    ErrorCode(
        "BC250-GPU-001",
        "The selected GPU telemetry source is unavailable.",
        "The active kernel or BIOS does not expose that sensor, or Cyan is using a telemetry method that this kernel does not support.",
        "For an unpatched kernel, select busy-flag or process. Use kernel only when gpu_busy_percent is readable, then apply Fix metrics or Fix frequencies only when needed.",
        markers=('QUICK_ACCESS_GPU_BUSY', 'gpu_busy_percent'),
    ),
    # Wording is shared verbatim with the desktop rule of the same identifier,
    # so the thirty locales translate both from one set of strings.
    ErrorCode(
        "BC250-CPUTOOL-001",
        'The audited CPU payload refused the requested value.',
        'The R64 detector shipped inside this build enforces its own limits, and they are narrower than what this screen offers: it accepts the stock CPU frequency and above, never below it, and it caps VID and temperature on its own terms.',
        'Ask for a value the payload accepts, or install a build whose audited payload carries the wider range. Nothing is missing and nothing needs reinstalling.',
        markers=('CPU_PAYLOAD_REFUSED',),
    ),
    ErrorCode(
        "BC250-HELPER-001",
        "A protected BC250 helper is missing or failed its safety check.",
        "The application and its root-owned helper are from different installs, or another toolkit changed the helper's owner, mode, or path.",
        "Reinstall BC250 Control Center. Do not copy a helper manually into /usr/libexec.",
        markers=(
            'CU_HELPER_MISSING', 'CU_BACKEND_UNTRUSTED', 'CPU_BACKEND_MISSING',
            'HELPER_PRIVILEGE', 'CPU_BACKEND_UNTRUSTED', 'QUICK_ACCESS_GPU_HELPER',
            'HELPER_UNTRUSTED',
            'reviewed root-owned SteamOS graphics backend is unavailable or changed',
            'protected BC250 OpenRC service helper is missing',
            'protected GDDR6 patch helper is not installed',
            'installation permission repair is unavailable',
            'install the local name repair helper',
            'install the LAN firewall helper',
            'to install the protected system setup helper',
        ),
    ),
    # An upstream release that hosts a pacman repository can be removed or
    # renamed; pacman then reports 404 and the run aborts. Nothing is wrong
    # locally, so this must not read as a machine problem.
    ErrorCode(
        "BC250-UPSTREAM-404",
        "The external package repository is temporarily unavailable at its address.",
        "The upstream project republishes this pacman repository as a GitHub release, and its assets are unavailable while that release is being rebuilt. The address is still the documented one, and nothing is wrong with this system or its network.",
        "Wait for the upstream rebuild to finish and run the workflow again later; the currently installed kernel keeps working meanwhile. Only report the diagnostic code if it still fails after a day.",
        markers=(
            "returned error: 404",
        ),
        # A mirror's 404 is a stale package list (PKG-005), not an upstream rebuild.
        requires="github.com",
    ),
    # The database was read but the files it names are gone from the mirrors: it
    # is older than they are. pacman prints this after its 404 lines, so a repo
    # that really moved (it fails earlier, at the database) keeps the rule above.
    ErrorCode(
        "BC250-PKG-005",
        "This system's package list is out of date.",
        "The list of packages on this computer names versions that the mirrors no longer carry. This happens when the system has not been updated for a while.",
        "Update the system with sudo pacman -Syu, then run this action again.",
        markers=(
            # No brackets: the terminal wrapper reads markers as regular expressions.
            "failed to retrieve some files",
        ),
        requires="returned error: 404",
    ),
    # R-d0e4fa7c: pacman (and paru/yay through it) stops with this when one
    # repository is defined twice, by pacman.conf and an Include file or by a
    # section copied in by hand. Nothing was installed; which copy to keep is
    # the owner's call, so the advice says how to find both.
    ErrorCode(
        "BC250-PKG-007",
        "The same package repository is configured twice.",
        "pacman found one repository defined twice: in /etc/pacman.conf and again in a file it includes, or in a section that was added by hand. It stops before installing anything.",
        "Run pacman-conf --repo-list | sort | uniq -d to see the repeated repository, keep one of its two definitions in /etc/pacman.conf or /etc/pacman.d, then run the action again.",
        markers=(
            "database already registered",
            # paru's own words for the same libalpm error (R-4e20acd3).
            "Database should be null",
        ),
    ),
    # R-f193b192: a package whose checksum does not match the repository's list
    # was taken for a signature problem, and the advice (update the keyring)
    # could not help. The kernel workflow now deletes the damaged copy and
    # downloads it again by itself; this explains it when that also fails.
    ErrorCode(
        "BC250-PKG-006",
        "A downloaded package was damaged.",
        "Its checksum did not match the repository's list: the download was cut short, or the repository published the file again with the same version. Nothing was installed.",
        "Run the action again: Control Center deletes the damaged copy and downloads it again. If it keeps failing, the repository is serving a damaged file right now; try again later.",
        markers=(
            # No brackets: the terminal wrapper reads markers as regular expressions.
            "corrupted package .checksum",
            "BC-250 repository is serving a damaged package",
        ),
    ),
    ErrorCode(
        "BC250-PKG-002",
        "The package signature or repository key could not be verified.",
        "The keyring may be outdated, the download may be incomplete, or an external repository has a trust configuration that differs from the selected workflow.",
        "Update the distribution keyring and retry. If this is an external repository, review its configured signature policy before changing pacman, DNF, or APT settings.",
        markers=(
            'signature from "',
            "invalid or corrupted package",
            "unknown public key",
            "unknown trust",
            "GPG check FAILED",
        ),
    ),
    # SteamOS refused to unlock, or failed to relock, its read-only root.
    ErrorCode(
        "BC250-IMMUTABLE-001",
        'The immutable system deployment is not ready for this change.',
        'Bazzite or SteamOS may have a pending update, rollback, rebase, or restart, or the selected workflow is intended for a mutable distribution.',
        'Finish the pending deployment and restart. Then use the Bazzite or SteamOS workflow shown by the compatibility filter.',
        markers=(
            'SteamOS reports a writable root',
            'SteamOS read-only state',
            'Failed to restore SteamOS read-only protection',
            'systemd-sysext or another immutable layer',
        ),
    ),
    # After IMMUTABLE-001 on purpose (a later text rule wins): the root was
    # reported writable, yet pacman could not write its database (R-fc1cfbe2).
    ErrorCode(
        "BC250-IMMUTABLE-002",
        "The SteamOS root was still read-only when packages were written.",
        "SteamOS reported a writable root, but the pacman database under /usr/lib/holo/pacmandb was still read-only when pacman wrote to it, so the transaction was aborted and no package was changed.",
        "Restart SteamOS and run the action again. If it repeats, report it with this code and the findmnt and steamos-readonly lines printed above; do not change the read-only state by hand.",
        markers=(
            'could not create directory',
            'pacman database is still read-only',
        ),
        requires="Read-only file system",
    ),
    # A pinned release or reviewed source revision could not be fetched.
    ErrorCode(
        "BC250-NET-001",
        'A required download could not be reached or verified.',
        'The network, DNS, proxy, system clock, certificate store, or upstream server interrupted the download.',
        'Confirm internet access and the system date, then retry. If a proxy or filtered network is in use, test the repository URL in a browser.',
        markers=(
            'Unable to download',
            'Reviewed source commit is unavailable after fetch',
            'Reviewed source revision could not be checked out',
            # sha256sum -c on a downloaded update package.
            'computed checksum did NOT match',
            # curl and git (R-530bd5f6, R-cc0af5ae, R-86b82fd2, R-86d44da1).
            # "returned error: 5" covers every 5xx; 404 keeps its own rules.
            'Could not resolve host', 'Temporary failure in name resolution',
            # Not a bare "nghttp2": package lists carry libnghttp2.
            'nghttp2 shuts down connection', 'FRAME_SIZE_ERROR', 'returned error: 5',
            'Connection timed out', 'Operation timed out',
            # curl 35 and 56 (R-c436fef5); not a bare reset, Wine prints that too.
            'Recv failure: Connection reset', 'Send failure: Connection reset',
        ),
    ),
    # A compiler, linker or make stopped (R-bb33f44b). After NET-001 so a
    # download error that was recovered from does not outrank the build that
    # failed after it; before RUNTIME-001, whose library mismatch is the
    # more precise cause when both appear. "] Error N" is make's own line;
    # "]" outside a bracket expression is literal in POSIX ERE.
    ErrorCode(
        "BC250-BUILD-003",
        "A build step failed.",
        "The compiler, linker or make stopped on an error before the program or module was produced. A missing header file means a development package (kernel headers or linux-api-headers) is not installed; another error names the file and line involved.",
        "Read the first compiler error in the log above. If it names a missing header, prepare dependencies from the Dashboard and retry; otherwise report the workflow with this code and the log.",
        markers=(
            'compilation terminated.', 'collect2: error', 'ninja: build stopped',
            'ld returned 1 exit status', '] Error ',
        ),
    ),
    # A binary built on a newer system (Oberon from fedora:latest on an older
    # Bazzite, R-53376560; the audio tools on SteamOS, R-79e92b51). Before
    # BUILD-001 so its SteamOS-specific marker still wins there.
    ErrorCode(
        "BC250-RUNTIME-001",
        "A program needs a newer system library than this system has.",
        "The program, or a build tool downloaded for it, was built against a newer glibc or libstdc++ than the one installed here, so Linux refuses to start it.",
        "Update the system and retry, or use a build made for this release. Never replace the system's glibc or libstdc++ by hand; if the program came from a BC250 workflow, report it with this code.",
        markers=('GLIBCXX_', 'CXXABI_', 'GLIBC_2.'),
        # The loader's own wording: "version `X' not found (required by Y)".
        requires="(required by",
    ),
    # The compiler itself is broken, so whatever was being built is not the
    # fault: R-12c6bac6 was reported as UMR and reinstalling UMR cannot work.
    # After UMR-001 and BUILD-003 so it wins over both.
    ErrorCode(
        "BC250-BUILD-004",
        "This system's compiler cannot link programs.",
        "A file of the compiler (libgcc_s) is missing or does not match the compiler. An interrupted or partial system update usually causes it.",
        "Update the whole system (sudo pacman -Syu on Arch-based systems), reinstall the gcc and gcc-libs packages, then run the action again.",
        markers=("unable to find library -lgcc_s", "cannot find -lgcc_s"),
    ),
    # The workflow printed its own [ERROR] lines, so its wording is shown
    # instead of a rule. This entry exists so the identifier is a registered
    # one that support can look up, not an invented string.
    ErrorCode(
        "BC250-WORKFLOW-001",
        "The workflow reported the failure itself.",
        "The workflow stopped on a condition it detected and described in its own output.",
        "Follow the steps the workflow printed above; they name the exact package, kernel or path involved.",
        # Quick Access runs the reviewed GDDR6 patch helper, whose own error
        # (unsupported firmware, governor starting, SMU busy) is the message.
        exit_statuses=(66,),
        markers=('per-game install unexpectedly enabled the driver system-wide', 'the reviewed SteamOS kernel backend supports', 'QUICK_ACCESS_GDDR6',),
    ),
    # DryhoppedIPA's install.sh refuses to install over a release. Fedora's
    # Install / update now removes the old release after the build, so this is
    # left for older Control Center versions and manual runs.
    ErrorCode(
        "BC250-GFX-001",
        "A GFX1013 fix release is already installed.",
        "The upstream installer does not install over an existing release, so the build finished but the install step stopped. The installed release and its boot entry were not changed.",
        "Run Install / update again from Control Center: it now replaces the previous release itself. To use the release already installed, press Boot with the fix and restart.",
        markers=('a release is already installed',),
    ),
    ErrorCode(
        "BC250-BUILD-002",
        "The SteamOS AMDGPU module could not be built.",
        "The compiler or a build tool failed before module installation. This does not establish a helper version mismatch.",
        "Read the first compiler or runtime error in the workflow log. The existing module remains installed; retry the compatibility repair after resolving that error.",
        markers=("STEAMOS_AMDGPU_BUILD_FAILED",),
    ),
    ErrorCode(
        "BC250-BUILD-001",
        "The SteamOS build tools are incompatible with the installed system libraries.",
        "A downloaded build tool requires a newer GLIBC runtime than this SteamOS provides, or its runtime preflight failed.",
        "Run SteamOS compatibility repair with the updated Control Center build, which uses the installed SteamOS branch and a separate dependency cache. Do not replace the system GLIBC libraries.",
        markers=("STEAMOS_BUILD_RUNTIME_INCOMPATIBLE",),
    ),
    ErrorCode(
        "BC250-PROTON-001",
        "The SteamOS GE-Proton action did not complete.",
        "The upstream installer stopped. Its preceding message identifies the missing RADV prerequisite, download, integrity or installation problem.",
        "Follow the upstream message in this log, then retry Install / update. A missing tool in a status check does not require reinstalling Control Center.",
        markers=("STEAMOS_PROTON_FAILED",),
    ),
    # Fallback: wording reused from the desktop diagnostic rules so it is
    # already translated in all 30 locales.
    ErrorCode(
        "BC250-GENERAL-001",
        "The operation could not be completed.",
        "The component returned a failure that does not yet match a more specific diagnostic rule.",
        "Read the technical detail below, refresh the affected page, and retry once. If it repeats, copy this complete diagnostic for support.",
    ),
)

GENERAL_FAILURE = _CODES[-1]

#: The calm dialog a hardware action shows on a PC that is not a BC-250; the
#: HW-001 entry above explains it. Defined here so the locales carry it.
HARDWARE_GATE_MESSAGE = (
    "This action changes BC-250 hardware, and no BC-250 (PCI 1002:13fe) was found in this computer. Nothing was changed."
)

BY_CODE: dict[str, ErrorCode] = {entry.code: entry for entry in _CODES}


def _index_exit_statuses() -> dict[int, ErrorCode]:
    index: dict[int, ErrorCode] = {}
    for entry in _CODES:
        for status in entry.exit_statuses:
            # First declaration wins so the table stays deterministic; a repeat
            # means two entries claim one status and the manifest test fails.
            index.setdefault(status, entry)
    return index


_BY_EXIT_STATUS = _index_exit_statuses()
_BY_MARKER: dict[str, ErrorCode] = {}
for _entry in _CODES:
    for _marker in _entry.markers:
        _BY_MARKER.setdefault(_marker, _entry)


def for_exit_status(status: object) -> ErrorCode | None:
    """Return the code a process exit status means, or None when unmapped.

    Only for known producers: the protected helpers, whose numbers this table
    was written for, and whose callers (``failure_text.describe_failure``)
    read the helper's own marker first. A terminal workflow's status is the
    status of whatever ran last (``make`` 2, ``curl`` 22, ``systemctl status``
    3) and means nothing here, so ``terminal_plan`` no longer consults it.

    Signals are reported as ``128 + n`` by the shell; they are not workflow
    failures with a fix, so they stay unmapped and render as the generic entry
    with the signal number preserved in the technical detail.
    """
    try:
        value = int(status)
    except (TypeError, ValueError):
        return None
    return _BY_EXIT_STATUS.get(value)


# Longest marker first: QUICK_ACCESS_CPU is a prefix of QUICK_ACCESS_CPU_VERIFY,
# so the more specific marker has to win.
_MARKERS_BY_LENGTH: tuple[tuple[str, ErrorCode], ...] = tuple(
    sorted(_BY_MARKER.items(), key=lambda item: len(item[0]), reverse=True)
)


def for_marker(text: object) -> ErrorCode | None:
    """Return the code a helper's ``PREFIX:`` stderr marker means.

    A helper that wraps another's error reads ``QUICK_ACCESS_CPU: SMU_IN_USE:
    ...``: the inner marker is the cause, so the one that starts last wins, and
    at the same place the longest (QUICK_ACCESS_CPU_VERIFY over
    QUICK_ACCESS_CPU).
    """
    detail = str(text or "")
    best: tuple[int, int, ErrorCode] | None = None
    for marker, entry in _MARKERS_BY_LENGTH:
        start = detail.rfind(marker)
        if entry.requires and entry.requires not in detail:
            continue
        if start >= 0 and (best is None or (start, len(marker)) > best[:2]):
            best = (start, len(marker), entry)
    return best[2] if best else None


def known_exit_statuses() -> frozenset[int]:
    """Every process exit status this catalog can explain."""
    return frozenset(_BY_EXIT_STATUS)


def all_codes() -> tuple[ErrorCode, ...]:
    return _CODES


def translatable_strings() -> tuple[str, ...]:
    """Every English source string here, for the i18n catalogs to collect."""
    seen: dict[str, None] = {}
    for entry in _CODES:
        for value in (entry.summary, entry.cause, entry.action):
            seen.setdefault(value, None)
    seen.setdefault(HARDWARE_GATE_MESSAGE, None)
    return tuple(seen)
