"""Isolated Control Center privileged runtime."""
